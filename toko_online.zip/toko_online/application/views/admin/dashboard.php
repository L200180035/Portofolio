<div class="container-fluid">
     <!-- Content Row -->
                    
<marquee>Selamat Datang Di Beranda Admin Aplikasi Toko Online Garuda Celuller</marquee>
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Dashboard</h2>   
                        <h5>Welcome Admin , Senang Melihatmu. </h5>
                    </div>
                </div>              
                 
             </div>
            </div>

</div>