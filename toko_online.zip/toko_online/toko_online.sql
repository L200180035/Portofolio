-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 31 Des 2020 pada 00.43
-- Versi server: 10.4.14-MariaDB
-- Versi PHP: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `toko_online`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_barang`
--

CREATE TABLE `tb_barang` (
  `id_brg` int(11) NOT NULL,
  `nama_brg` varchar(120) NOT NULL,
  `keterangan` varchar(225) NOT NULL,
  `kategori` varchar(60) NOT NULL,
  `harga` int(11) NOT NULL,
  `stok` int(4) NOT NULL,
  `gambar` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_barang`
--

INSERT INTO `tb_barang` (`id_brg`, `nama_brg`, `keterangan`, `kategori`, `harga`, `stok`, `gambar`) VALUES
(1, 'Samsung Galaxy A71', 'RAM 2 Gb, Memori Internal 128 Gb', 'Samsung', 5000000, 6, 'a51.jpg'),
(2, 'Samsung Galaxy S20', 'RAM 16 Gb, Memori Internal 512 Gb', 'Samsung', 10000000, 10, 's20.jpg'),
(3, 'Samsung Galaxy Fold', 'RAM 16 Gb, Memori Internal 512 Gb', 'Samsung', 200000000, 9, 'fold.jpg'),
(4, 'Xiaomi Redmi Note 7', 'RAM 8 Gb, Memori Internal 64 Gb', 'Xiaomi', 4500000, 10, 'redminote7.jpg'),
(5, 'Iphone 12', 'RAM 16 Gb, Memori Internal 512 Gb', 'Iphone', 350000000, 12, 'iphone12.jpg'),
(8, 'Vivo Y91', 'RAM 4 Gb, Memori Internal 64 Gb', 'Vivo', 3100000, 12, 'y91.jpeg'),
(9, 'Advan G5', 'RAM 2 Gb, Memori Internal 16 Gb', 'Advan', 1000000, 12, 'g5.jpg'),
(10, 'Oppo A5(2020)', 'RAM 8 Gb, Memori Internal 128 Gb', 'Oppo', 15000000, 12, 'a52020.jpg'),
(11, 'Oppo A91', 'RAM 8 Gb, Memori Internal 128 Gb', 'Oppo', 2800000, 15, 'a91.png'),
(12, 'Oppo A5S', 'RAM 8 Gb, Memori Internal 64 Gb', 'Oppo', 3500000, 11, 'a5s.jpg'),
(13, 'Iphone 11', 'RAM 6 Gb, Memori Internal 128 Gb', 'Iphone', 9000000, 12, 'iphone111.jpg'),
(14, 'Iphone X', 'RAM 4 Gb, Memori Internal 64 Gb', 'Iphone', 8000000, 5, 'iphone10.jpg'),
(15, 'Xiaomi Mi 10', 'RAM 8 Gb, Memori Internal 256 Gb', 'Xiaomi', 13000000, 16, 'mi10.png'),
(17, 'Xiaomi Redmi 5A', 'RAM 2 Gb, Memori Internal 16 Gb', 'Xiaomi', 1300000, 15, 'redmi5a1.jpg'),
(18, 'Vivo Y20', 'RAM 3 Gb, Memori Internal 32 Gb', 'Vivo', 2000000, 20, 'Y20.jpg'),
(19, 'Vivo Y91C', 'RAM 3 Gb, Memori Internal 32 Gb', 'Vivo', 2500000, 20, 'y91c.jpg'),
(20, 'Advan G1', 'RAM 2 Gb, Memori Internal 16 Gb', 'Advan', 800000, 20, 'g1.jpg'),
(21, 'Advan I6', 'RAM 2 Gb, Memori Internal 16 Gb', 'Advan', 500000, 14, 'i6.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_invoice`
--

CREATE TABLE `tb_invoice` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `tgl_pesan` datetime NOT NULL,
  `batas_bayar` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_invoice`
--

INSERT INTO `tb_invoice` (`id`, `nama`, `alamat`, `tgl_pesan`, `batas_bayar`) VALUES
(1, 'Luqman Hanung Asidiq', 'Sukoharjo', '2020-12-05 02:55:35', '2020-12-06 02:55:35'),
(2, 'Arsya Rizki Suwarno', 'Sukoharjo', '2020-12-05 08:58:03', '2020-12-06 08:58:03'),
(3, 'Budi Santoso', 'Solo', '2020-12-05 09:09:54', '2020-12-06 09:09:54'),
(4, 'Donny Supriyanto', 'Klaten', '2020-12-05 20:43:07', '2020-12-06 20:43:07'),
(5, 'Suhartono', 'Bekasi', '2020-12-06 05:49:59', '2020-12-07 05:49:59'),
(7, 'Luqman Hanung Asidiq', 'Solo', '2020-12-09 16:27:35', '2020-12-10 16:27:35'),
(8, 'Luqman Hanung Asidiq', 'Sukoharjo', '2020-12-14 16:36:54', '2020-12-15 16:36:54');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pesanan`
--

CREATE TABLE `tb_pesanan` (
  `id` int(11) NOT NULL,
  `id_invoice` int(11) NOT NULL,
  `id_brg` int(11) NOT NULL,
  `nama_brg` varchar(50) NOT NULL,
  `jumlah` int(3) NOT NULL,
  `harga` int(10) NOT NULL,
  `pilihan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_pesanan`
--

INSERT INTO `tb_pesanan` (`id`, `id_invoice`, `id_brg`, `nama_brg`, `jumlah`, `harga`, `pilihan`) VALUES
(1, 1, 1, 'Samsung Galaxy A71', 2, 5000000, ''),
(2, 1, 2, 'Samsung Galaxy S20', 1, 10000000, ''),
(3, 2, 1, 'Samsung Galaxy A71', 1, 5000000, ''),
(4, 2, 2, 'Samsung Galaxy S20', 1, 10000000, ''),
(5, 2, 3, 'Samsung Galaxy Fold', 1, 200000000, ''),
(6, 3, 5, 'Iphone 12', 1, 350000000, ''),
(7, 3, 4, 'Xiaomi Redmi Note 7', 1, 4500000, ''),
(8, 4, 1, 'Samsung Galaxy A71', 2, 5000000, ''),
(9, 5, 1, 'Samsung Galaxy A71', 1, 5000000, ''),
(10, 6, 1, 'Samsung Galaxy A71', 1, 5000000, ''),
(11, 7, 1, 'Samsung Galaxy A71', 1, 5000000, ''),
(12, 8, 3, 'Samsung Galaxy Fold', 1, 200000000, '');

--
-- Trigger `tb_pesanan`
--
DELIMITER $$
CREATE TRIGGER `pesanan_penjualan` AFTER INSERT ON `tb_pesanan` FOR EACH ROW BEGIN
	UPDATE tb_barang SET stok = stok-NEW.jumlah
    WHERE id_brg = NEW.id_brg;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_user`
--

CREATE TABLE `tb_user` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role_id` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_user`
--

INSERT INTO `tb_user` (`id`, `nama`, `username`, `password`, `role_id`) VALUES
(1, 'admin', 'admin', '123', 1),
(2, 'user', 'user', '123', 2),
(3, 'Luqman Hanung Asidiq', 'luqmanhanung', '123', 2),
(4, 'Arsya Rizki Suwarno', 'arsyarizki', '123', 2),
(5, 'Budi', 'budi', '123', 2),
(6, 'Deni', 'deni', '123', 2);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_barang`
--
ALTER TABLE `tb_barang`
  ADD PRIMARY KEY (`id_brg`);

--
-- Indeks untuk tabel `tb_invoice`
--
ALTER TABLE `tb_invoice`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_pesanan`
--
ALTER TABLE `tb_pesanan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_barang`
--
ALTER TABLE `tb_barang`
  MODIFY `id_brg` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT untuk tabel `tb_invoice`
--
ALTER TABLE `tb_invoice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `tb_pesanan`
--
ALTER TABLE `tb_pesanan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
