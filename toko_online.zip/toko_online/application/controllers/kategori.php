<?php 

class Kategori extends CI_Controller{
	public function samsung()
	{
		$data['samsung'] = $this->model_kategori->data_samsung()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('samsung', $data);
		$this->load->view('templates/footer');
	}

	public function xiaomi()
	{
		$data['xiaomi'] = $this->model_kategori->data_xiaomi()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('xiaomi', $data);
		$this->load->view('templates/footer');
	}

	public function iphone()
	{
		$data['iphone'] = $this->model_kategori->data_iphone()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('iphone', $data);
		$this->load->view('templates/footer');
	}

	public function oppo()
	{
		$data['oppo'] = $this->model_kategori->data_oppo()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('oppo', $data);
		$this->load->view('templates/footer');
	}

	public function vivo()
	{
		$data['vivo'] = $this->model_kategori->data_vivo()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('vivo', $data);
		$this->load->view('templates/footer');
	}

	public function advan()
	{
		$data['advan'] = $this->model_kategori->data_advan()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('advan', $data);
		$this->load->view('templates/footer');
	}

	public function asus()
	{
		$data['asus'] = $this->model_kategori->data_asus()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('asus', $data);
		$this->load->view('templates/footer');
	}

	public function lenovo()
	{
		$data['lenovo'] = $this->model_kategori->data_lenovo()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('lenovo', $data);
		$this->load->view('templates/footer');
	}

	public function lava()
	{
		$data['lava'] = $this->model_kategori->data_lava()->result();
		$this->load->view('templates/header');
		$this->load->view('templates/sidebar');
		$this->load->view('lava', $data);
		$this->load->view('templates/footer');
	}
}