<?php 

class Model_kategori extends CI_Model{
	public function data_samsung(){
		return $this->db->get_where('tb_barang', array('kategori' => 'samsung'));
	}

	public function data_xiaomi(){
		return $this->db->get_where('tb_barang', array('kategori' => 'xiaomi'));
	}

	public function data_iphone(){
		return $this->db->get_where('tb_barang', array('kategori' => 'iphone'));
	}

	public function data_oppo(){
		return $this->db->get_where('tb_barang', array('kategori' => 'oppo'));
	}

	public function data_vivo(){
		return $this->db->get_where('tb_barang', array('kategori' => 'vivo'));
	}

	public function data_advan(){
		return $this->db->get_where('tb_barang', array('kategori' => 'advan'));
	}

	public function data_asus(){
		return $this->db->get_where('tb_barang', array('kategori' => 'asus'));
	}

	public function data_lenovo(){
		return $this->db->get_where('tb_barang', array('kategori' => 'lenovo'));
	}

	public function data_lava(){
		return $this->db->get_where('tb_barang', array('kategori' => 'lava'));
	}
}